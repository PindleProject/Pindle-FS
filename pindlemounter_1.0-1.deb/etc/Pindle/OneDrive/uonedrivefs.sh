#!/usr/bin/bash

python3 /etc/Pindle/OneDrive/umount_onedrive.py > /dev/null &
